default['java']['jdk_version'] = '8'
default['java']['remove_deprecated_packages'] = true
default['java']['oracle']['accept_oracle_download_terms'] = true
# default['java']['java_home'] = '/usr/lib/java/default'
default['java']['set_default'] = true
default['java_ark']['connect_timeout'] = 1200
